import crypto from 'crypto';
// Generate a random secret key
const secretKey = crypto.randomBytes(256).toString('base64');

console.log('Generated secret key:', secretKey);
