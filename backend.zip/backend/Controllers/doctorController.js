import Doctor from "../models/DoctorSchema.js";

export const updateDoctor = async (req, res) => {
    const id = req.params.id;
    try {
        const updateDoctor = await Doctor.findByIdAndUpdate(
            id,
            req.body, // Updated doctor data
            { new: true } // Options: return the modified document
        );
        res.status(200)
            .json({
                success: true,
                message: 'Successfully Updated',
                data: updateDoctor,
            });
    } catch (err) {
        res.status(500).json({ success: false, message: 'Failed to Update' });
    }
};

export const deleteDoctor = async (req, res) => {
    const id = req.params.id;
    try {
        await Doctor.findByIdAndDelete(id);
        res.status(200)
            .json({
                success: true,
                message: 'Successfully deleted',
            });
    } catch (err) {
        res.status(500).json({ success: false, message: 'Failed to delete' });
    }
};

export const getSingleDoctor = async (req, res) => {
    const id = req.params.id;
    try {
        const doctor = await Doctor.findById(id).select('-password');
        if (!doctor) {
            return res.status(404).json({ success: false, message: 'Doctor not found' });
        }
        res.status(200)
            .json({
                success: true,
                message: 'Doctor Found',
                data: doctor,
            });
    } catch (err) {
        res.status(500).json({ success: false, message: 'Internal server error' });
    }
};

export const getAllDoctor = async (req, res) => {
    try {
        
        const {query} = req.query;
        let doctors;

        if(query){
            doctors = await Doctor.find({
                isApproved:'approved',
        $or:[
         {name: { $regex: query, $options: 'i'} } ,
         {specialization: { $regex: query, $options: 'i'} }            
         ],
        }).select('-password');
    }
    else{
        doctors = await Doctor.find({}).select('-password');
    }
       
        res.status(200)
            .json({
                success: true,
                message: 'Doctors Found',
                data: doctors,
            });
    } catch (err) {
        res.status(500).json({ success: false, message: 'Internal server error' });
    }
};
